====================================================================
 Client IRC prive -- IRCImproved
====================================================================

DEMARRER
--------
1. Extraire TOUT le zip dans un dossier ou tu peux ecrire : tes
   Documents, le Bureau, une cle USB. Surtout PAS dans
   C:\Program Files : HexChat et Tor doivent ecrire leur
   configuration et leurs journaux a cote de start.bat.
2. Double-cliquer start.bat.
3. Au premier lancement, le script demande ton pseudo. Une seule
   fois : il est ensuite retenu dans nick.txt, a cote de start.bat.
4. Attendre que la barre de progression de Tor atteigne 100 %
   (de quelques secondes a 2-3 minutes selon ta connexion).
   HexChat s ouvre alors et se connecte tout seul au serveur.

IMPORTANT : laisse la fenetre noire OUVERTE pendant toute la session.
C est elle qui fait tourner Tor. La fermer coupe la connexion.
Pour quitter : ferme HexChat, la fenetre noire se referme ensuite
toute seule et arrete Tor.

RELANCER
--------
Double-cliquer start.bat a nouveau. Le pseudo n est plus demande.
Les lancements suivants sont plus rapides : Tor garde son cache.
Pour changer de pseudo : modifier nick.txt, ou le supprimer pour que
la question revienne au prochain lancement.

SI WINDOWS OU L ANTIVIRUS SE PLAINT
-----------------------------------
Un zip recu par mail ou Discord est marque "venu d Internet".

* "Windows a protege votre ordinateur" (SmartScreen) sur start.bat :
  cliquer "Informations complementaires" puis "Executer quand meme".
  Ou, avant d extraire : clic droit sur le zip > Proprietes > cocher
  "Debloquer" > OK, puis extraire.

* L antivirus met tor.exe en quarantaine : tor.exe n est pas signe
  numeriquement, certains antivirus s en mefient par principe. Il faut
  l autoriser (ou ajouter le dossier aux exclusions). Sans lui, pas de
  connexion possible.

SI CA NE MARCHE PAS
-------------------
* "Tor n a pas fini de demarrer" : relancer start.bat. Si ca bloque
  encore, le reseau filtre peut-etre Tor (wifi d entreprise, hotel,
  certains operateurs mobiles) : essayer depuis un autre reseau ou un
  partage de connexion telephone.
* HexChat s ouvre mais reste sur "Connexion..." : normal pendant
  quelques dizaines de secondes, le temps de trouver le service cache.
  HexChat reessaie tout seul.
* La liste des serveurs s ouvre au lieu de la connexion : le dossier
  HexChatProfile est abime. Le supprimer et relancer start.bat.

TOUT ENLEVER
------------
Double-cliquer uninstall.bat, puis supprimer le dossier.
uninstall.bat enleve le cache de Tor et le profil HexChat de ce
package. Il ne desinstalle HexChat que si c est ce package qui l a
installe, et il ne touche pas a ta configuration HexChat personnelle
dans %APPDATA%\HexChat.

CE QUE CONTIENT CE DOSSIER
--------------------------
start.bat / start.ps1  le lanceur
uninstall.bat          la desinstallation
profile\               les modeles de configuration HexChat
tor\tor\tor.exe        le client Tor portable
PACKAGE-INFO.txt       date, serveur et channel de ce package

Cree a l execution : nick.txt, HexChatProfile\, tor\torrc,
tor\tor.log, tor\data\ (cache Tor, quelques dizaines de Mo).

A SAVOIR
--------
Ce package contient l adresse .onion du serveur et son mot de passe de
connexion en clair. Quiconque recupere ce zip peut se connecter au
serveur : ne le redistribue pas.
